# fib
**Fill in yout team member names and computing IDs**
* Bhasitha Dharmasena  bp2sq bp2sq-uva
* Sorawich Maichum    sm9cq  sm9cq


In this exercise you will work as a team using a shared GitHub repository.  Automatic testing will be triggered following each push to the repository.  These tests typically take a minute or so to start and run, depending on the server load at GitHub.  You can check on the status of your tests under the "Actions" link at the top of this page.

See the class workflow page for more details on the code you will write.  Note that two solutions are required, one written in C++ and one in Python.
