# fits2

fit_user.C : demo code for mkaing a user-defined fitting function.  Poorly choosen starting parameters selected here will prevent the minimizer from converging.<br>
data1.root : used with fit_user.C 

datadist.root : contains a hisogram "h" that should be fit using a function of your own choosing
