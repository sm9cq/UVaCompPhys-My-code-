# salesman
I submit the redo version with sales_redo.cpp, sales_redo_c.cpp and sales_redo.pdf
* datareader.cpp : example code to read in the data files
* cities.dat : list of coordinates for 23 cities in North America
* cities2.dat : 150 cities in North America
* cities3.dat : 1207 cities in North America
* cities4.dat : 2063 cities around the world

* sales.plt : example plotting script to overlay path of travel with a map 
* world.plt : another example, but with a Mercator projection of the whole earth
