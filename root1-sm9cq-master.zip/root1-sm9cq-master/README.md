# root1

A few very basic examples are given for using thg ROOT with its C++ and Python interfaces.  We will use a very liites subset of the ROOT libraries in this class.  Most of the functionallity we need will be introduced in examples with started code.  