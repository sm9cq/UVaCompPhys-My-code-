# ex02: Show and tell example of different quadrature rules for integration
The plot "compareinteg.pdf" shows errors vs intervals of integration of various methods of integration.
These are trapazoidal, Simpsom's ,and Gauss rule.

The purple plot show the slowest algorithm which is the trapazoidal rule.
The fastest algorithm is Gauss rule.

From my opinion, I think these methods are suitable for each function with different original ideas. The trap integral is inspired by the linear section with a constant slope. So, I think this approximation will make a difference when the used function is upper than 2nd order polynomials.

Secondly, the Simpson's rule bases on 2nd order polynomials  fitting. For more curvy function, this method is better than the trap rule.

Finally, the Gauss rule is the best method to get the least error, because of 3rd order polynomial approximation. 
