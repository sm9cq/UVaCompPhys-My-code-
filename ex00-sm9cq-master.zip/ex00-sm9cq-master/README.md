# ex00

This repository gives a few examples for how to plot the volume of hypershperes of different radii and dimensions.
  * nSphere.ipynb : Jupyter notebook file, vire on Rivanna using: <br> jupyter-notebook nSphere.ipynb <br>The notebook includes a few plotting examples to related to our first exercise.
  * nSphere.cpp : a simple C++ program that dumps data to stdout <br> run make to build and generate a plot using a gnuplot script.