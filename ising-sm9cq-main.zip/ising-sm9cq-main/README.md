# ising

If the class website is down, see the file IsingandMetropolis.pdf for a copy of today's exercise.


Sorawich Maichum - sm9cq
