# ode3
Part A:
The first part of this exercise is to be completed **individually**.  In github classroom this will be listed as assignment **ode3A**.

Part B: Will be completed in teams of 2.

Team members:
Sorawich Maichum sm9cq
Sachinthani premathilake sap5ug
