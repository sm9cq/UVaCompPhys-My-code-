#!/usr/bin/env python 

from ctypes import cdll  # pythonic interfaces for C(++) libraries
from ctypes import c_double
from math import exp
import sys
import argparse
import random

# load our library and define the input/output interfaces
mylib=cdll.LoadLibrary('./mexp.soc')
# we have to define input/ouput data types for EVERY function we want to use
# in a particular library
mylib.mexp.argtypes=[c_double]  # input data type[s]
mylib.mexp.restype=c_double     # return value type

parser = argparse.ArgumentParser(description='mexp program checker')
parser.add_argument('-t', '--testrange', type=int, default=0, help='test range')
args = parser.parse_args()


#        0   1       2   3   4  5  6 
ranges=[0.0,0.98222,1.5,2.0,9.0,20,100,700]

t=args.testrange
if t>(len(ranges)-2):
    print("test out of range")
    sys.exit(1)

min=ranges[t]
max=ranges[t+1]
x=random.random() * (max-min) + min

val=mylib.mexp(x)

# test
rel=1e-8
err=abs(val-exp(-x))/exp(-x)
if err < rel: print(f'test{t} exp(-{x})={val}, rel error = {err}, passed within tolerence')
else: print(f'test{t} exp(-{x})!={val}, rel error = {err}, test failed')

