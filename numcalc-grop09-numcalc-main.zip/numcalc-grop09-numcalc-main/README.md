# numcalc: Numerical calculation exercise

Team members:
* Sorawich Maichum  sm9cq
* Hunter Presley hp4xz

See description for this exercise in class workflow page
