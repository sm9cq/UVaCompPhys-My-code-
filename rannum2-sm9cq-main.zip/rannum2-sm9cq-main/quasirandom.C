//+______________________________________________________________________________
// Example of generating quasi-random numbers

#include "Math/QuasiRandom.h"
#include "TRandom3.h"
#include "TH2D.h"
#include "TCanvas.h"
#include "TStopwatch.h"
#include "TGClient.h"
#include "TStyle.h"

#include <iostream>

using namespace ROOT::Math;

int quasirandom(int n = 40000, int skip = 0) {
  //gStyle->SetOptStat(0);
  
   TH2D * h0 = new TH2D("h0","Pseudo-random Sequence",200,0,1,200,0,1);
   TH2D * h1 = new TH2D("h1","Sobol Sequence",200,0,1,200,0,1);
   TH2D * h2 = new TH2D("h2","Niederrer Sequence",200,0,1,200,0,1);

   TRandom3         r0(0);
   // quasi random numbers need to be created giving the dimension of the sequence
   // in this case we generate a 2-d sequence

   QuasiRandomSobol r1(2);
   QuasiRandomNiederreiter r2(2);

   // generate n random points
   double x[2];
   TStopwatch w; w.Start();
   for (int i = 0; i < n; ++i)  {
      r0.RndmArray(2,x);
      h0->Fill(x[0],x[1]);
   }
   std::cout << "Time for TRandom3 ";
   w.Print();

   w.Start();
   if( skip>0) r1.Skip(skip);
   for (int i = 0; i < n; ++i)  {
      r1.Next(x);
      h1->Fill(x[0],x[1]);
   }
   std::cout << "Time for Sobol ";
   w.Print();

   w.Start();
   if( skip>0) r2.Skip(skip);
   for (int i = 0; i < n; ++i)  {
      r2.Next(x);
      h2->Fill(x[0],x[1]);
   }
   std::cout << "Time for Niederreiter ";
   w.Print();


   // plot the 2D pairs of random numbers
   UInt_t dw = gClient->GetDisplayWidth();
   UInt_t dh = gClient->GetDisplayHeight();

   /*
   TCanvas * c1 = new TCanvas("c0","Random and quasirandom sequences",dw/2,dh/2);
   c1->Divide(1,3);

   c1->cd(1);

   h0->Draw("COLZ");
   double max=h0->GetBinContent(h0->GetMaximumBin());

   // check uniformity
   c1->cd(2);
   h1->SetMaximum(max);
   h1->Draw("COLZ");

   c1->cd(3);
   h2->SetMaximum(max);
   h2->Draw("COLZ");

   gPad->Update();
   */
   
   // test number of empty bins

   int nzerobins0 = 0;
   int nzerobins1 = 0;
   int nzerobins2 = 0;
   for (int i = 1; i <= h1->GetNbinsX(); ++i) {
      for (int j = 1; j <= h1->GetNbinsY(); ++j) {
         if (h0->GetBinContent(i,j) == 0 ) nzerobins0++;
         if (h1->GetBinContent(i,j) == 0 ) nzerobins1++;
         if (h2->GetBinContent(i,j) == 0 ) nzerobins2++;
      }
   }


   // plot projections in X,Y for the different generators
   TCanvas * cr = new TCanvas("cr","Pseudorandom sequence",dh*0.8,dh*0.8);
   cr->Divide(2,2);
   cr->cd(1);
   h0->ProjectionY()->Draw();
   cr->cd(2);
   h0->Draw("colz");
   cr->cd(4);
   h0->ProjectionX()->Draw();

   TCanvas * cs = new TCanvas("cs","Sobol sequence",100,100,dh*0.8,dh*0.8);
   cs->Divide(2,2);
   cs->cd(1);
   h1->ProjectionY()->Draw();
   cs->cd(2);
   h1->Draw("colz");
   cs->cd(4);
   h1->ProjectionX()->Draw();
   
   TCanvas * cn = new TCanvas("cn","Niederreiter sequence",150,100,dh*0.8,dh*0.8);
   cn->Divide(2,2);
   cn->cd(1);
   h2->ProjectionY()->Draw();
   cn->cd(2);
   h2->Draw("colz");
   cn->cd(4);
   h2->ProjectionX()->Draw();
  
   
   std::cout << "number of empty bins for pseudo-random = " << nzerobins0 << std::endl;
   std::cout << "number of empty bins for " << r1.Name() << "\t= " << nzerobins1 << std::endl;
   std::cout << "number of empty bins for " << r2.Name() << "\t= " << nzerobins2 << std::endl;

   int iret = 0;
   if (nzerobins1 >= nzerobins0 ) iret += 1;
   if (nzerobins2 >= nzerobins0 ) iret += 2;


   return iret;
}
